<?php
/**
 * Test script for the public gatepass download functionality
 * 
 * This script simulates different gatepass download scenarios to verify correct operation
 * 
 * @author Piyush Maji
 */

// Include configuration
require_once 'includes/config.php';

// Function to run test
function runTest() {
    echo "<h1>Testing Public Gatepass Download Functionality</h1>";
    
    // First, get a valid gatepass ID from the database for testing
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
    
    // Get a valid approved gatepass
    $valid_gatepass = null;
    $result = $conn->query("SELECT gatepass_id FROM gatepasses WHERE status = 'approved' LIMIT 1");
    
    if ($result && $result->num_rows > 0) {
        $valid_gatepass = $result->fetch_assoc()['gatepass_id'];
    }
    
    // Get a non-approved gatepass
    $non_approved_gatepass = null;
    $result = $conn->query("SELECT gatepass_id FROM gatepasses WHERE status != 'approved' LIMIT 1");
    
    if ($result && $result->num_rows > 0) {
        $non_approved_gatepass = $result->fetch_assoc()['gatepass_id'];
    }
    
    // Get an invalid gatepass ID (one that doesn't exist)
    $invalid_gatepass = 'INVALID123456';
    
    // Run tests
    echo "<h2>Test Results</h2>";
    echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr style='background-color:#f1f1f1'><th>Test Case</th><th>Gatepass ID</th><th>Expected Result</th><th>Test URL</th></tr>";
    
    // Test cases
    $test_cases = [
        [
            'name' => 'Valid Approved Gatepass',
            'id' => $valid_gatepass,
            'expected' => 'Should download PDF successfully',
            'url' => 'public_download.php?gatepass_id=' . urlencode($valid_gatepass)
        ],
        [
            'name' => 'Non-Approved Gatepass',
            'id' => $non_approved_gatepass,
            'expected' => 'Should show error message',
            'url' => 'public_download.php?gatepass_id=' . urlencode($non_approved_gatepass)
        ],
        [
            'name' => 'Invalid Gatepass ID',
            'id' => $invalid_gatepass,
            'expected' => 'Should show error message',
            'url' => 'public_download.php?gatepass_id=' . urlencode($invalid_gatepass)
        ],
        [
            'name' => 'Empty Gatepass ID',
            'id' => '',
            'expected' => 'Should show the form',
            'url' => 'public_download.php'
        ],
        [
            'name' => 'Verify Valid Gatepass',
            'id' => $valid_gatepass,
            'expected' => 'Should show verification details',
            'url' => 'verify_gatepass.php?id=' . urlencode($valid_gatepass)
        ]
    ];
    
    foreach ($test_cases as $test) {
        echo "<tr>";
        echo "<td>{$test['name']}</td>";
        echo "<td>{$test['id']}</td>";
        echo "<td>{$test['expected']}</td>";
        echo "<td><a href='{$test['url']}' target='_blank'>Test This Case</a></td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Additional verification test
    echo "<h2>QR Code Test</h2>";
    echo "<p>Scan this QR code to test the verification process:</p>";
    
    if ($valid_gatepass) {
        // Include QR code generator
        require_once 'includes/qrcode.php';
        
        // Generate QR code for verification
        $verification_url = BASE_URL . "verify_gatepass.php?id=" . urlencode($valid_gatepass);
        $qr_code = new QRCodeGenerator(200, 10, 'H');
        echo $qr_code->generateHtmlImage($verification_url, 'Verify Gatepass QR Code', ['style' => 'border: 1px solid #ccc; padding: 10px;']);
        
        echo "<p>This QR code should open the verification page for gatepass: {$valid_gatepass}</p>";
    } else {
        echo "<p>No valid gatepass found for QR testing.</p>";
    }
    
    // Test the security verification
    echo "<h2>Security Verification Test</h2>";
    echo "<p>Use this form to test the security verification process:</p>";
    
    if ($valid_gatepass) {
        echo "<form action='security_verify.php' method='post' style='border: 1px solid #ccc; padding: 20px; max-width: 500px;'>";
        echo "<div style='margin-bottom: 10px;'><label>Gatepass ID:</label> <input type='text' name='gatepass_id' value='{$valid_gatepass}' readonly style='width: 100%; padding: 5px;'></div>";
        echo "<div style='margin-bottom: 10px;'><label>Security Code (use 'security123'):</label> <input type='text' name='security_code' value='security123' style='width: 100%; padding: 5px;'></div>";
        echo "<div style='margin-bottom: 10px;'><label>Verification Notes:</label> <textarea name='verification_notes' style='width: 100%; padding: 5px;'>Test verification from test script</textarea></div>";
        echo "<div><input type='submit' value='Test Verification' style='padding: 10px 20px; background: #2c3e50; color: white; border: none;'></div>";
        echo "</form>";
    } else {
        echo "<p>No valid gatepass found for security verification testing.</p>";
    }
    
    // Close connection
    $conn->close();
}

// Check if user is authenticated admin (for security)
if (isset($_SESSION['role']) && $_SESSION['role'] == 'admin') {
    runTest();
} else {
    echo "<h1>Unauthorized Access</h1>";
    echo "<p>You must be logged in as an administrator to run this test script.</p>";
    echo "<p><a href='index.php'>Return to Login</a></p>";
}
?>
