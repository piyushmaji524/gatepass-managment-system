-- Migrations to add returnable fields to gatepass_items table
ALTER TABLE `gatepass_items` 
ADD COLUMN `is_returnable` TINYINT(1) DEFAULT 0,
ADD COLUMN `returned` TINYINT(1) DEFAULT 0,
ADD COLUMN `return_date` DATETIME DEFAULT NULL,
ADD COLUMN `returned_by` INT(11) DEFAULT NULL;

-- Add foreign key constraint for returned_by
ALTER TABLE `gatepass_items`
ADD CONSTRAINT `gatepass_items_ibfk_2` FOREIGN KEY (`returned_by`) REFERENCES `users` (`id`);
