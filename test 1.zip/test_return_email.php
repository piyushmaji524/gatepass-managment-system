<?php
// Test script to verify email functionality for returnable items
require_once 'includes/config.php';

// Check if the user is logged in
if (!isLoggedIn()) {
    header("Location: index.php");
    exit();
}

// Connect to the database
$conn = connectDB();

// Function to test the email sending for returnable items
function testReturnableItemEmail() {
    global $conn;
    
    // Get a sample gatepass with returnable items
    $stmt = $conn->prepare("
        SELECT g.id as gatepass_id, g.gatepass_number, i.id as item_id
        FROM gatepasses g
        JOIN gatepass_items i ON i.gatepass_id = g.id
        WHERE i.is_returnable = 1 AND (i.returned = 0 OR i.returned IS NULL)
        AND g.status = 'approved_by_security'
        LIMIT 1
    ");
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $gatepass_id = $data['gatepass_id'];
        $item_id = $data['item_id'];
        
        // Get gatepass details including creator and admin info
        $stmt = $conn->prepare("
            SELECT g.*, 
                   i.item_name, i.quantity, i.unit,
                   creator.name as creator_name, creator.email as creator_email,
                   admin.name as admin_name, admin.email as admin_email
            FROM gatepasses g
            JOIN gatepass_items i ON i.gatepass_id = g.id AND i.id = ?
            JOIN users creator ON g.created_by = creator.id
            LEFT JOIN users admin ON g.admin_approved_by = admin.id
            WHERE g.id = ?
        ");
        $stmt->bind_param("ii", $item_id, $gatepass_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $gatepass_data = $result->fetch_assoc();
        
        // Prepare data for email
        $email_gatepass_data = array(
            'gatepass_number' => $gatepass_data['gatepass_number'],
            'from_location' => $gatepass_data['from_location'],
            'to_location' => $gatepass_data['to_location'],
            'material_type' => $gatepass_data['material_type'],
            'status' => 'ITEM RETURNED',
            'returned_item_name' => $gatepass_data['item_name'],
            'returned_quantity' => $gatepass_data['quantity'],
            'returned_unit' => $gatepass_data['unit'],
            'return_date' => date('d M Y, h:i A')
        );
        
        // Test email to user
        $subject = "Item Returned: Gatepass #" . $gatepass_data['gatepass_number'] . " (TEST)";
        $message = "This is a test email. The following item has been returned and marked as received: <br><br>";
        $message .= "<strong>Item:</strong> " . $gatepass_data['item_name'] . "<br>";
        $message .= "<strong>Quantity:</strong> " . $gatepass_data['quantity'] . " " . $gatepass_data['unit'] . "<br>";
        $message .= "<strong>Return Date:</strong> " . date('d M Y, h:i A') . "<br><br>";
        $message .= "This item is now confirmed as returned to the premises.";
        $action_url = APP_URL . "/user/view_gatepass.php?id=" . $gatepass_id;
        $action_text = "View Gatepass";
        
        $user_email_sent = sendEmailNotification(
            $gatepass_data['creator_email'],
            $gatepass_data['creator_name'],
            $subject,
            $message,
            $email_gatepass_data,
            $action_url,
            $action_text
        );
        
        // Test email to admin
        $admin_email_sent = false;
        if (!empty($gatepass_data['admin_email'])) {
            $admin_subject = "Item Returned: Gatepass #" . $gatepass_data['gatepass_number'] . " (TEST)";
            $admin_message = "This is a test email. An item from a gatepass you approved has been returned: <br><br>";
            $admin_message .= "<strong>Item:</strong> " . $gatepass_data['item_name'] . "<br>";
            $admin_message .= "<strong>Quantity:</strong> " . $gatepass_data['quantity'] . " " . $gatepass_data['unit'] . "<br>";
            $admin_message .= "<strong>Created By:</strong> " . $gatepass_data['creator_name'] . "<br>";
            $admin_message .= "<strong>Return Date:</strong> " . date('d M Y, h:i A') . "<br><br>";
            $admin_message .= "This item is now confirmed as returned to the premises.";
            $admin_action_url = APP_URL . "/admin/view_gatepass.php?id=" . $gatepass_id;
            
            $admin_email_sent = sendEmailNotification(
                $gatepass_data['admin_email'],
                $gatepass_data['admin_name'],
                $admin_subject,
                $admin_message,
                $email_gatepass_data,
                $admin_action_url,
                $action_text
            );
        }
        
        return [
            'success' => true,
            'user_email' => [
                'recipient' => $gatepass_data['creator_email'],
                'sent' => $user_email_sent
            ],
            'admin_email' => [
                'recipient' => $gatepass_data['admin_email'] ?? 'Not available',
                'sent' => $admin_email_sent
            ],
            'gatepass_number' => $gatepass_data['gatepass_number'],
            'item' => $gatepass_data['item_name'],
        ];
    } else {
        return [
            'success' => false,
            'message' => 'No pending returnable items found for testing.'
        ];
    }
}

// Set page title
$page_title = "Test Returnable Item Emails";

// Include header
include 'includes/header.php';

// Run the test if requested
$test_results = null;
if (isset($_GET['run_test']) && $_GET['run_test'] == '1') {
    $test_results = testReturnableItemEmail();
}
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-envelope me-2"></i>Test Returnable Item Emails</h2>
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Home
        </a>
    </div>
    
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Email Test Tool</h5>
        </div>
        <div class="card-body">
            <p class="mb-3">
                This tool allows you to test the email notification system for returnable items. Click the button below to simulate sending emails for a returned item.
            </p>
            
            <a href="?run_test=1" class="btn btn-primary">
                <i class="fas fa-paper-plane me-2"></i>Run Email Test
            </a>
        </div>
    </div>
    
    <?php if ($test_results): ?>
    <div class="card">
        <div class="card-header bg-<?php echo $test_results['success'] ? 'success' : 'danger'; ?> text-white">
            <h5 class="mb-0">Test Results</h5>
        </div>
        <div class="card-body">
            <?php if ($test_results['success']): ?>
                <div class="alert alert-success">
                    <h5><i class="fas fa-check-circle me-2"></i>Test emails sent successfully!</h5>
                    <p>Gatepass Number: <?php echo $test_results['gatepass_number']; ?><br>
                    Item: <?php echo $test_results['item']; ?></p>
                </div>
                
                <h6 class="mb-3">Email Delivery Status:</h6>
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>Recipient Type</th>
                            <th>Email Address</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Gatepass Creator</td>
                            <td><?php echo $test_results['user_email']['recipient']; ?></td>
                            <td>
                                <?php if ($test_results['user_email']['sent']): ?>
                                    <span class="badge bg-success"><i class="fas fa-check me-1"></i>Sent</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Failed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>Admin Approver</td>
                            <td><?php echo $test_results['admin_email']['recipient']; ?></td>
                            <td>
                                <?php if ($test_results['admin_email']['sent']): ?>
                                    <span class="badge bg-success"><i class="fas fa-check me-1"></i>Sent</span>
                                <?php elseif ($test_results['admin_email']['recipient'] == 'Not available'): ?>
                                    <span class="badge bg-secondary"><i class="fas fa-minus me-1"></i>N/A</span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><i class="fas fa-times me-1"></i>Failed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <div class="alert alert-info mt-3">
                    <i class="fas fa-info-circle me-2"></i>
                    These are test emails and have "(TEST)" in the subject line. The actual emails sent when 
                    marking items as returned will not include this label.
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    <h5><i class="fas fa-exclamation-triangle me-2"></i>Test Failed</h5>
                    <p><?php echo $test_results['message']; ?></p>
                </div>
                <p>
                    Make sure there are pending returnable items in the system that have been verified by security
                    but not yet returned.
                </p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php
// Include footer
include 'includes/footer.php';

// Close the database connection
$conn->close();
?>
