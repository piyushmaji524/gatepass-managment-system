<?php
/**
 * Test script for validating returnable status rendering in PDFs
 * This script prints the returnable status for all items in a specified gatepass
 */
require_once "includes/config.php";

// Change this to test a specific gatepass ID
$test_gatepass_id = 1; // Replace with a valid gatepass ID from your system

echo "TESTING RETURNABLE FIELDS DISPLAY\n";
echo "=================================\n\n";

// Connect to database
$conn = connectDB();

// Get all items for the specified gatepass
$sql = "
    SELECT gi.id, gi.gatepass_id, gi.item_name, gi.quantity, gi.unit, 
           gi.is_returnable, gi.returned, gi.return_date, gi.returned_by, 
           u.name as returned_by_name 
    FROM gatepass_items gi
    LEFT JOIN users u ON gi.returned_by = u.id
    WHERE gi.gatepass_id = $test_gatepass_id
";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Gatepass #$test_gatepass_id Items:\n";
    echo "-----------------\n";
    
    while ($item = $result->fetch_assoc()) {
        echo "Item ID: " . $item['id'] . "\n";
        echo "Name: " . $item['item_name'] . "\n";
        echo "is_returnable: " . ($item['is_returnable'] ? "Yes" : "No") . " (Value: " . $item['is_returnable'] . ")\n";
        
        if ($item['is_returnable']) {
            echo "returned: " . ($item['returned'] ? "Yes" : "No") . " (Value: " . $item['returned'] . ")\n";
            
            if ($item['returned']) {
                echo "return_date: " . $item['return_date'] . "\n";
                echo "returned_by: " . $item['returned_by_name'] . " (ID: " . $item['returned_by'] . ")\n";
            }
        }
        
        echo "-----------------\n";
    }
} else {
    echo "No items found for gatepass #$test_gatepass_id\n";
}

$conn->close();
echo "\nTest completed. Check the values above to ensure returnable fields are correctly retrieved from the database.\n";
?>
