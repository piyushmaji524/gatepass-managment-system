<?php
// Include configuration and necessary files 
require_once 'includes/config.php';
require_once 'includes/rate_limiter.php';

// Initialize variables
$error = '';
$success = '';
$gatepass_data = null;
$show_form = true;

// Check rate limiting
$rate_limiter = new RateLimiter(10, 3600); // 10 attempts per hour
if (!$rate_limiter->isAllowed($_SERVER['REMOTE_ADDR'], 'public_download')) {
    $error = "Too many download attempts. Please try again later.";
    $show_form = false;
}

// Process form submission or direct access via GET
if ((isset($_POST['gatepass_id']) && $_SERVER['REQUEST_METHOD'] === 'POST') || isset($_GET['gatepass_id'])) {
    $gatepass_id = isset($_POST['gatepass_id']) ? trim($_POST['gatepass_id']) : trim($_GET['gatepass_id']);
    
    // Validate input
    if (empty($gatepass_id)) {
        $error = "Please enter a valid gatepass number.";
    } else {
        // Connect to database
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            $error = "Database connection failed. Please try again later.";
        } else {            // Secure query to get gatepass details
            $stmt = $conn->prepare("SELECT g.*, u.name as requester_name 
                                   FROM gatepasses g 
                                   JOIN users u ON g.created_by = u.id 
                                   WHERE g.gatepass_number = ? AND (g.status = 'approved_by_admin' 
                                   OR g.status = 'approved_by_security' OR g.status = 'self_approved')");
            $stmt->bind_param("s", $gatepass_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $gatepass_data = $result->fetch_assoc();
                $success = "Gatepass found! You can now download it.";
                $show_form = false;
                  // Log this access for security purposes
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
                $log_stmt = $conn->prepare("INSERT INTO logs (action, details, ip_address, user_agent) 
                                           VALUES ('Public Gatepass Download', ?, ?, ?)");
                $details = "Gatepass ID: " . $gatepass_id;
                $log_stmt->bind_param("sss", $details, $ip_address, $user_agent);
                $log_stmt->execute();
                $log_stmt->close();
                
                // Redirect to the download script with parameters
                header("Location: public_download_pdf.php?gatepass_id=" . urlencode($gatepass_id));
                exit();
            } else {
                $error = "Gatepass not found or not approved. Please check the gatepass number and try again.";
            }
            
            $stmt->close();
            $conn->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download Gatepass - <?php echo APP_NAME; ?></title>
    
    <!-- Favicon -->
    <?php 
        $favicon_path = 'assets/img/';
    ?>
    <!-- Standard Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?php echo $favicon_path; ?>favicon.svg">
    <link rel="icon" type="image/png" href="<?php echo $favicon_path; ?>favicon.png" sizes="32x32">
    <link rel="icon" type="image/x-icon" href="<?php echo $favicon_path; ?>favicon.ico">
    
    <!-- Apple Touch Icon -->
    <link rel="apple-touch-icon" href="<?php echo $favicon_path; ?>favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $favicon_path; ?>apple-touch-icon.png">
    
    <!-- Android Chrome -->
    <link rel="manifest" href="<?php echo $favicon_path; ?>site.webmanifest">
    <meta name="theme-color" content="#2c3e50">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        .download-container {
            max-width: 550px;
            margin: 5% auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container i {
            font-size: 48px;
            color: #2c3e50;
        }
        .form-title {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }
        .custom-btn {
            background-color: #2c3e50;
            border-color: #2c3e50;
            width: 100%;
        }
        .custom-btn:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        .back-to-login {
            text-align: center;
            margin-top: 20px;
        }
        .footer {
            text-align: center;
            font-size: 0.85em;
            color: #6c757d;
            margin-top: 20px;
        }
        .footer a {
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="download-container">
            <div class="logo-container">
                <i class="fas fa-id-card-alt"></i>
                <h2 class="mt-2"><?php echo APP_NAME; ?></h2>
            </div>
            
            <h3 class="form-title">Download Gatepass</h3>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($show_form): ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="mb-4">
                    <label for="gatepass_id" class="form-label">Gatepass Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-passport"></i></span>
                        <input type="text" class="form-control" id="gatepass_id" name="gatepass_id" placeholder="Enter gatepass number" required>
                    </div>
                    <small class="form-text text-muted">Enter the gatepass number to download the approved gatepass.</small>
                </div>
                
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary custom-btn">
                        <i class="fas fa-search me-2"></i>Find & Download Gatepass
                    </button>
                </div>
            </form>
            <?php endif; ?>            <div class="back-to-login">
                <a href="index.php">Back to Login</a> | 
                <a href="verify_gatepass.php">Verify a Gatepass</a> |
                <a href="public_services.php">Public Services Portal</a>
            </div>
            
            <div class="footer">
                <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> - Developed by <a href="copyright.php">Piyush Maji</a></p>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
