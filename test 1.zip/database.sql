-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 31, 2025 at 08:59 AM
-- Server version: 10.11.10-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u435643473_gpass`
--

-- --------------------------------------------------------

--
-- Table structure for table `gatepasses`
--

CREATE TABLE `gatepasses` (
  `id` int(11) NOT NULL,
  `gatepass_number` varchar(20) NOT NULL,
  `from_location` varchar(255) NOT NULL,
  `to_location` varchar(255) NOT NULL,
  `material_type` varchar(100) NOT NULL,
  `purpose` text DEFAULT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `requested_date` date NOT NULL,
  `requested_time` time NOT NULL,
  `status` enum('pending','approved_by_admin','approved_by_security','declined','self_approved') DEFAULT 'pending',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `admin_approved_by` int(11) DEFAULT NULL,
  `admin_approved_at` datetime DEFAULT NULL,
  `security_approved_by` int(11) DEFAULT NULL,
  `security_approved_at` datetime DEFAULT NULL,
  `declined_by` int(11) DEFAULT NULL,
  `declined_at` datetime DEFAULT NULL,
  `decline_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gatepass_items`
--

CREATE TABLE `gatepass_items` (
  `id` int(11) NOT NULL,
  `gatepass_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `is_returnable` tinyint(1) DEFAULT 0,
  `returned` tinyint(1) DEFAULT 0,
  `return_date` datetime DEFAULT NULL,
  `returned_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','security','user') NOT NULL,
  `status` enum('active','inactive','pending') DEFAULT 'pending',
  `can_self_approve` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `role`, `status`, `can_self_approve`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2a$10$aIxG9w.5OnGU3Ich.c6hkudcRGhEvGMVc0XDrVWmqZLqxgNLeA1py', 'Admin User', 'admin@example.com', 'admin', 'active', 0, '2025-05-28 14:32:43', '2025-05-28 16:32:53'),
(2, 'security', '$2a$10$ihP2ij56vl8HV1B5QbBg1u63BeL9XCVb7ZEQxuJZ4HdUGX2q.inn2', 'Security Officer', 'security@example.com', 'security', 'active', 0, '2025-05-28 14:32:43', '2025-05-28 16:31:27'),
(3, 'user', '$2a$10$v/3zS2kmQRJw2E4fmHIxhu0U9aqPyLn5u23aIhim3epdIUDy9Sr9W', 'Regular User', 'user@example.com', 'user', 'active', 0, '2025-05-28 14:32:43', '2025-05-28 14:39:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gatepasses`
--
ALTER TABLE `gatepasses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `gatepass_number` (`gatepass_number`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `admin_approved_by` (`admin_approved_by`),
  ADD KEY `security_approved_by` (`security_approved_by`),
  ADD KEY `declined_by` (`declined_by`);

--
-- Indexes for table `gatepass_items`
--
ALTER TABLE `gatepass_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gatepass_id` (`gatepass_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gatepasses`
--
ALTER TABLE `gatepasses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `gatepass_items`
--
ALTER TABLE `gatepass_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gatepasses`
--
ALTER TABLE `gatepasses`
  ADD CONSTRAINT `gatepasses_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `gatepasses_ibfk_2` FOREIGN KEY (`admin_approved_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `gatepasses_ibfk_3` FOREIGN KEY (`security_approved_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `gatepasses_ibfk_4` FOREIGN KEY (`declined_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `gatepass_items`
--
ALTER TABLE `gatepass_items`
  ADD CONSTRAINT `gatepass_items_ibfk_1` FOREIGN KEY (`gatepass_id`) REFERENCES `gatepasses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
