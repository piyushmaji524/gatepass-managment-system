<?php
// Include configuration and necessary files
require_once 'includes/config.php';
require_once 'fpdf/fpdf.php';
require_once 'includes/qrcode.php';
require_once 'includes/rate_limiter.php';

// Check if this is a QR code scan (coming from a mobile device)
$is_qr_scan = false;
if (isset($_SERVER['HTTP_USER_AGENT'])) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    // Basic check for mobile devices (can be more sophisticated)
    if (strpos($user_agent, 'Mobile') !== false || 
        strpos($user_agent, 'Android') !== false || 
        strpos($user_agent, 'iPhone') !== false || 
        strpos($user_agent, 'iPad') !== false) {
        $is_qr_scan = true;
    }
}

// Check rate limiting, but be more lenient for QR code scans
$rate_limiter = new RateLimiter($is_qr_scan ? 20 : 10, 3600); // More attempts allowed for QR scans
if (!$rate_limiter->isAllowed($_SERVER['REMOTE_ADDR'], 'download_pdf')) {
    header("Location: public_download.php?error=" . urlencode("Too many download attempts. Please try again later."));
    exit();
}

// Check if gatepass_id is provided
if (!isset($_GET['gatepass_id']) || empty($_GET['gatepass_id'])) {
    header("Location: public_download.php");
    exit();
}

$gatepass_id = trim($_GET['gatepass_id']);

// Connect to database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Secure query to get gatepass details
$stmt = $conn->prepare("SELECT g.*, u.name as requester_name
                       FROM gatepasses g 
                       JOIN users u ON g.created_by = u.id 
                       WHERE g.gatepass_number = ? AND (g.status = 'approved_by_admin' 
                       OR g.status = 'approved_by_security' OR g.status = 'self_approved')");
$stmt->bind_param("s", $gatepass_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if gatepass exists and is approved
if ($result->num_rows == 0) {
    header("Location: public_download.php");
    exit();
}

$gatepass = $result->fetch_assoc();

// Get items for this gatepass
$items_stmt = $conn->prepare("SELECT * FROM gatepass_items WHERE gatepass_id = ?");
$items_stmt->bind_param("i", $gatepass['id']);  // Using the gatepass id
$items_stmt->execute();
$items_result = $items_stmt->get_result();
$gatepass['items'] = [];
while ($item = $items_result->fetch_assoc()) {
    $gatepass['items'][] = $item;
}
$items_stmt->close();

// Log this download
$ip_address = $_SERVER['REMOTE_ADDR'];
$user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
$log_stmt = $conn->prepare("INSERT INTO logs (action, details, ip_address, user_agent) 
                           VALUES ('Public Gatepass PDF Download', ?, ?, ?)");
$details = "Gatepass Number: " . $gatepass_id;
$log_stmt->bind_param("sss", $details, $ip_address, $user_agent);
$log_stmt->execute();
$log_stmt->close();

// Create PDF
class GatePassPDF extends FPDF {
    function Header() {
        global $gatepass;
        
        // Logo or Title
        $this->SetFont('Arial', 'B', 18);
        $this->Cell(0, 10, APP_NAME, 0, 1, 'C');
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'GATE PASS', 0, 1, 'C');
        $this->Ln(5);
        
        // Add "PUBLIC COPY" watermark in the header
        $this->SetFont('Arial', 'B', 12);
        $this->SetTextColor(200, 50, 50);
        $this->Cell(0, 8, 'PUBLIC COPY - ' . date('d-m-Y H:i:s'), 0, 1, 'L');
        $this->SetTextColor(0, 0, 0);
        $this->Ln(2);
          // Gatepass ID and Date in a box
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Gatepass Number: ' . $gatepass['gatepass_number'], 0, 1, 'R');
        $this->Cell(0, 10, 'Issue Date: ' . date('d-m-Y', strtotime($gatepass['created_at'])), 0, 1, 'R');
        // Calculate validity date as requested_date + 7 days
        $valid_until = date('d-m-Y', strtotime($gatepass['requested_date'] . ' + 7 days'));
        $this->Cell(0, 10, 'Valid Until: ' . $valid_until, 0, 1, 'R');
        $this->Ln(10);
    }
    
    // Add diagonal watermark text throughout the document
    function Watermark($text) {
        // Save the current position
        $this->_out('q');
        $this->_out('1 0 0 1 0 0 cm');
        $this->_out('q');
        $this->_out('0.5 g'); // 50% gray
        $this->_out('BT');
        $this->_out('/F1 40 Tf');
        $this->_out('45 Tr');
        // Rotate 45 degrees and position
        $this->_out('0.7071 0.7071 -0.7071 0.7071 ' . ($this->w/4) . ' ' . ($this->h/2) . ' Tm');
        $this->_out('(' . $text . ') Tj');
        $this->_out('ET');
        $this->_out('Q');
        $this->_out('Q');
    }
    
    function Footer() {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');        // Add QR code information message
        $this->SetY(-25);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Scan QR code to download this gatepass or visit ' . APP_URL . ' for more information', 0, 0, 'C');
        
        // Developer credit
        $this->SetY(-20);
        $this->SetFont('Arial', 'I', 7);
        $this->Cell(0, 10, APP_NAME . ' - Developed by Piyush Maji', 0, 0, 'C');
    }
}

// Initialize PDF
$pdf = new GatePassPDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 30); // 30mm bottom margin for footer
$pdf->Watermark('PUBLIC COPY');

// Requester Information
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Requester Information:', 0, 1);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(40, 8, 'Name:', 0);
$pdf->Cell(0, 8, $gatepass['requester_name'], 0, 1);
$pdf->Cell(40, 8, 'From Location:', 0);
$pdf->Cell(0, 8, $gatepass['from_location'], 0, 1);
$pdf->Cell(40, 8, 'To Location:', 0);
$pdf->Cell(0, 8, $gatepass['to_location'], 0, 1);
$pdf->Cell(40, 8, 'Purpose:', 0);
$pdf->Cell(0, 8, $gatepass['purpose'], 0, 1);
$pdf->Ln(5);

// Item Details
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Item Details:', 0, 1);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(10, 8, '#', 1);
$pdf->Cell(80, 8, 'Item Description', 1);
$pdf->Cell(30, 8, 'Quantity', 1);
$pdf->Cell(30, 8, 'Returnable', 1);
$pdf->Cell(40, 8, 'Return Date', 1);
$pdf->Ln();

// Get items data
$items_stmt = $conn->prepare("SELECT * FROM gatepass_items WHERE gatepass_id = ?");
$items_stmt->bind_param("i", $gatepass['id']); // Using the gatepass ID from retrieved record
$items_stmt->execute();
$items_result = $items_stmt->get_result();

// Add item rows
$pdf->SetFont('Arial', '', 10);
$i = 1;
while ($item = $items_result->fetch_assoc()) {
    $pdf->Cell(10, 8, $i, 1);
    $pdf->Cell(80, 8, $item['item_name'], 1);  // Changed from description to item_name
    $pdf->Cell(30, 8, $item['quantity'] . ' ' . $item['unit'], 1);
    $pdf->Cell(30, 8, ($item['is_returnable'] ? 'Yes' : 'No'), 1);
    $pdf->Cell(40, 8, ($item['is_returnable'] ? date('d-m-Y', strtotime($item['return_date'])) : 'N/A'), 1);
    $pdf->Ln();
    $i++;
}
$items_stmt->close();

// Approval Information
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Approval Information:', 0, 1);
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(40, 8, 'Status:', 0);

// Format the status for better readability
$status = str_replace('_', ' ', $gatepass['status']);
$pdf->Cell(0, 8, ucwords($status), 0, 1);

// Determine the approver based on status
$approver_name = "Not Available";
$approval_date = "Not Available";

if ($gatepass['status'] == 'approved_by_admin' && !empty($gatepass['admin_approved_by'])) {
    // Get admin name from database
    $admin_stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $admin_stmt->bind_param("i", $gatepass['admin_approved_by']);
    $admin_stmt->execute();
    $admin_result = $admin_stmt->get_result();
    if ($admin_result->num_rows > 0) {
        $admin = $admin_result->fetch_assoc();
        $approver_name = $admin['name'];
    }
    $admin_stmt->close();
    
    // Format approval date if available
    if (!empty($gatepass['admin_approved_at'])) {
        $approval_date = date('d-m-Y H:i:s', strtotime($gatepass['admin_approved_at']));
    }
} else if ($gatepass['status'] == 'approved_by_security' && !empty($gatepass['security_approved_by'])) {
    // Get security name from database
    $security_stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $security_stmt->bind_param("i", $gatepass['security_approved_by']);
    $security_stmt->execute();
    $security_result = $security_stmt->get_result();
    if ($security_result->num_rows > 0) {
        $security = $security_result->fetch_assoc();
        $approver_name = $security['name'];
    }
    $security_stmt->close();
    
    // Format approval date if available
    if (!empty($gatepass['security_approved_at'])) {
        $approval_date = date('d-m-Y H:i:s', strtotime($gatepass['security_approved_at']));
    }
} else if ($gatepass['status'] == 'self_approved') {
    $approver_name = $gatepass['requester_name'] . " (Self-Approved)";
    $approval_date = date('d-m-Y H:i:s', strtotime($gatepass['created_at']));
}

$pdf->Cell(40, 8, 'Approved By:', 0);
$pdf->Cell(0, 8, $approver_name, 0, 1);
$pdf->Cell(40, 8, 'Approval Date:', 0);
$pdf->Cell(0, 8, $approval_date, 0, 1);
// Show remarks if available (use decline_reason since that's what's in the database schema)
if (!empty($gatepass['decline_reason'])) {
    $pdf->Cell(40, 8, 'Remarks:', 0);
    $pdf->MultiCell(0, 8, $gatepass['decline_reason'], 0);
}

// QR Code Generation
$pdf->Ln(10);
$pdf->Cell(0, 10, 'Direct Download QR Code:', 0, 1);

// Generate QR code for direct PDF download instead of verification
$download_url = APP_URL . "/public_download_pdf.php?gatepass_id=" . urlencode($gatepass_id);
$qr_code = new QRCodeGenerator(300, 10, 'H');
$qr_filename = 'temp_qr_' . $gatepass_id . '.png';
$qr_filepath = sys_get_temp_dir() . '/' . $qr_filename;

// Generate and save QR code to temporary file
$qr_code->generateAndSave($verification_url, $qr_filepath);

// Add QR code to PDF with explanation text
$pdf->Image($qr_filepath, null, null, 50, 50, 'PNG', $download_url);
$pdf->SetY($pdf->GetY() + 50);
$pdf->SetFont('Arial', 'I', 9);
$pdf->Cell(0, 10, 'Scan this code to directly download a copy of this gatepass', 0, 1, 'C');
$pdf->Ln(5);

// Delete temporary QR code file
@unlink($qr_filepath);

// Security Verification Section
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Security Verification:', 0, 1);
$pdf->SetFont('Arial', '', 11);
if (!empty($gatepass['security_approved_by'])) {
    // Get security name
    $security_verify_stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $security_verify_stmt->bind_param("i", $gatepass['security_approved_by']);
    $security_verify_stmt->execute();
    $security_verify_result = $security_verify_stmt->get_result();
    $security_name = "Security Officer";
    if ($security_verify_result->num_rows > 0) {
        $security_user = $security_verify_result->fetch_assoc();
        $security_name = $security_user['name'];
    }
    $security_verify_stmt->close();
    
    $pdf->Cell(40, 8, 'Verified By:', 0);
    $pdf->Cell(0, 8, $security_name, 0, 1);
    $pdf->Cell(40, 8, 'Verified Date:', 0);
    $pdf->Cell(0, 8, date('d-m-Y H:i:s', strtotime($gatepass['security_approved_at'])), 0, 1);
} else {
    $pdf->Cell(0, 8, 'Not verified by security yet', 0, 1);
}

// Terms and Conditions
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Terms & Conditions:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(0, 6, '1. This gatepass must be presented at the security gate.
2. All items must be inspected by security before exiting.
3. Returnable items must be returned by the specified date.
4. The gatepass is valid only until the expiration date.
5. Any discrepancy may result in denial of exit permission.');

// Output the PDF - 'D' forces download, 'I' displays in browser
if ($is_qr_scan) {
    // If accessed from QR code scan (mobile), display in browser for immediate viewing
    $pdf->Output('I', 'Gatepass-' . $gatepass_id . '.pdf');
} else {
    // Normal web access - force download
    $pdf->Output('D', 'Gatepass-' . $gatepass_id . '.pdf');
}

// Close database connection
$conn->close();
?>
