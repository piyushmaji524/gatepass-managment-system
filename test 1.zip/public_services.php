<?php
// Include configuration
require_once 'includes/config.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Services - <?php echo APP_NAME; ?></title>
    
    <!-- Favicon -->
    <?php 
        $favicon_path = 'assets/img/';
    ?>
    <!-- Standard Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?php echo $favicon_path; ?>favicon.svg">
    <link rel="icon" type="image/png" href="<?php echo $favicon_path; ?>favicon.png" sizes="32x32">
    <link rel="icon" type="image/x-icon" href="<?php echo $favicon_path; ?>favicon.ico">
    
    <!-- Apple Touch Icon -->
    <link rel="apple-touch-icon" href="<?php echo $favicon_path; ?>favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $favicon_path; ?>apple-touch-icon.png">
    
    <!-- Android Chrome -->
    <link rel="manifest" href="<?php echo $favicon_path; ?>site.webmanifest">
    <meta name="theme-color" content="#2c3e50">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
        }
        .main-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 30px;
        }
        .header-section {
            text-align: center;
            padding: 30px 0;
            background: linear-gradient(135deg, #3498db, #2c3e50);
            color: white;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .header-section h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        .header-section p {
            font-size: 1.2rem;
            max-width: 600px;
            margin: 0 auto;
        }
        .service-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
        }
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .card-icon {
            font-size: 3rem;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        .footer {
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            color: #6c757d;
        }
        .footer a {
            color: #2c3e50;
        }
        .back-to-login {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <div class="header-section">
            <h1><i class="fas fa-id-card-alt me-3"></i><?php echo APP_NAME; ?></h1>
            <p>Access public services for the gatepass system including verification and downloads.</p>
        </div>
        
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <div class="card-icon">
                            <i class="fas fa-download"></i>
                        </div>
                        <h4 class="card-title">Download Gatepass</h4>
                        <p class="card-text">Download your approved gatepass using your gatepass ID number.</p>
                        <a href="public_download.php" class="btn btn-primary">
                            <i class="fas fa-arrow-right me-2"></i>Download Gatepass
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <div class="card-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <h4 class="card-title">Verify Gatepass</h4>
                        <p class="card-text">Verify the authenticity of a gatepass and check its current status.</p>
                        <a href="verify_gatepass.php" class="btn btn-success">
                            <i class="fas fa-arrow-right me-2"></i>Verify Gatepass
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-4">
                <div class="card service-card">
                    <div class="card-body text-center">
                        <div class="card-icon">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <h4 class="card-title">Information</h4>
                        <p class="card-text">Learn about the gatepass system and how to use it effectively.</p>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#infoModal" class="btn btn-info">
                            <i class="fas fa-arrow-right me-2"></i>More Information
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-md-6 mb-4">
                <div class="card service-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-question-circle me-2"></i>FAQ</h5>
                        <div class="accordion" id="faqAccordion">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                        What is a gatepass?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        A gatepass is an official document that authorizes the movement of items in and out of the premises. It ensures proper tracking and security of all assets.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        How do I get a gatepass?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        Gatepasses must be requested by authorized users through the system. Login to your account and create a new gatepass request, which will then be reviewed by administrators.
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        What if my gatepass is lost?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        If your gatepass is lost, you can download a new copy using your gatepass ID number through this portal. If you do not know your gatepass ID, please contact the administrator.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="card service-card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-phone-alt me-2"></i>Contact Support</h5>
                        <p>Need help with the gatepass system? Contact our support team:</p>
                        <ul class="list-group list-group-flush">                            <li class="list-group-item">
                                <i class="fas fa-envelope me-2"></i> Email: support@example.com
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-phone me-2"></i> Phone: +91 123-456-7890
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-clock me-2"></i> Hours: Mon-Fri, 9:00 AM - 5:00 PM
                            </li>
                        </ul>
                        <div class="d-grid gap-2 mt-3">                            <a href="mailto:support@example.com" class="btn btn-outline-primary">
                                <i class="fas fa-paper-plane me-2"></i>Contact Support
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="back-to-login">
            <a href="index.php" class="btn btn-outline-secondary">
                <i class="fas fa-sign-in-alt me-2"></i>Login to System
            </a>
        </div>
        
        <div class="footer">
            <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> - Developed by <a href="copyright.php">Piyush Maji</a></p>
        </div>
    </div>
    
    <!-- Information Modal -->
    <div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="infoModalLabel">About the Gatepass System</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">                    <h4>What is the Gatepass System?</h4>
                    <p>The Gatepass System is a comprehensive digital solution designed to manage and track the movement of items in and out of the premises. It replaces traditional paper-based systems with a secure, efficient, and transparent process.</p>
                    
                    <h4>Key Features:</h4>
                    <ul>
                        <li><strong>Digital Gatepasses:</strong> Create, approve, and verify gatepasses digitally</li>
                        <li><strong>Item Tracking:</strong> Keep track of all items leaving and returning to the premises</li>
                        <li><strong>Security Verification:</strong> Security personnel can verify and validate gatepasses at entry/exit points</li>
                        <li><strong>Return Tracking:</strong> Monitor returnable items and get notified when items are due for return</li>
                        <li><strong>PDF Downloads:</strong> Download gatepass documents for offline use</li>
                        <li><strong>QR Code Verification:</strong> Quick verification using QR codes</li>
                    </ul>
                    
                    <h4>How to Use the Public Portal:</h4>
                    <ol>
                        <li>To download a gatepass, you need your gatepass ID number</li>
                        <li>To verify a gatepass, enter the gatepass ID or scan the QR code</li>
                        <li>For security personnel: Use your security code to mark gatepasses as verified</li>
                    </ol>
                    
                    <p>For full access to the system including creating new gatepasses, you need to log in with authorized credentials.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
