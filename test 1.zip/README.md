# Gatepass Management System

A comprehensive web-based system for managing material exit requests within an organization. This system facilitates a secure and efficient workflow for requesting, approving, and verifying gatepasses for materials leaving the premises.

## Features

### User Roles

1. **User**
   - Create new gatepass requests
   - View and track their own gatepasses
   - Edit pending gatepasses
   - Download approved gatepasses

2. **Admin**
   - View all gatepasses in the system
   - Approve or decline gatepass requests
   - Manage user accounts (create, approve, deactivate)
   - Generate reports

3. **Security**
   - Verify approved gatepasses
   - Search for gatepasses by number or details
   - Scan barcode for quick verification
   - View verification history

### System Features

- Secure authentication and role-based access control
- Real-time status tracking of gatepasses
- PDF generation with barcode for verified gatepasses
- Activity logging for audit purposes
- Responsive design for desktop and mobile use

## Tech Stack

- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+ / MariaDB 10+
- **Frontend**: HTML5, CSS3, JavaScript
- **CSS Framework**: Bootstrap 5
- **Icons**: Font Awesome 6
- **PDF Generation**: FPDF Library

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/username/gatepass-management-system.git
   cd gatepass-management-system
   ```

2. Set up the database:
   - Create a MySQL database
   - Import the `database.sql` file into your database

3. Configure the application:
   - Copy `includes/config.php.template` to `includes/config.php`
   - Edit `config.php` with your database credentials and other settings:
     ```php
     define('DB_HOST', 'localhost');
     define('DB_USER', 'your_database_user');
     define('DB_PASS', 'your_database_password');
     define('DB_NAME', 'your_database_name');
     define('APP_URL', 'https://your-domain.com');
     ```

4. Set proper permissions:
   - Ensure the `uploads` directory is writable by the web server
   - Secure your files with appropriate permissions

5. Set up a virtual host (optional):
   - Configure your web server to point to the project directory
   - Example for Apache:
     ```
     <VirtualHost *:80>
         ServerName gatepass.yourdomain.com
         DocumentRoot /path/to/gatepass-management-system
         <Directory "/path/to/gatepass-management-system">
             AllowOverride All
             Require all granted
         </Directory>
     </VirtualHost>
     ```

6. Access the application:
   - Visit the site in your browser
   - Log in with the default admin credentials (then change them immediately):
     - Username: admin
     - Password: admin123

## Default Accounts

The system comes with three default accounts for testing:

1. **Admin Account**
   - Username: admin
   - Password: admin123

2. **Security Account**
   - Username: security
   - Password: security123

3. **User Account**
   - Username: user
   - Password: user123

**Note**: It is highly recommended to change these default passwords after installation.

## Directory Structure

```
gatepass-management-system/
├── admin/         # Admin role pages
├── assets/        # CSS, JavaScript, images
├── fpdf/          # PDF generation library
├── includes/      # Shared PHP files
├── security/      # Security role pages
├── templates/     # Reusable HTML templates
├── uploads/       # Uploaded files
├── user/          # User role pages
├── database.sql   # Database schema
├── index.php      # Login page
├── logout.php     # Logout functionality
└── README.md      # This file
```

## Workflow

1. **User** creates a new gatepass request with details of materials
2. **Admin** reviews the request and approves or declines it
3. **User** receives notification of approval/decline
4. **Security** verifies the approved gatepass when materials exit
5. **User** can download the PDF of the verified gatepass

## License

This project is licensed under the [MIT License](LICENSE) - see the LICENSE file for details.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## Acknowledgments

- Developed by [Piyush Maji](https://github.com/piyushmaji524)
- Bootstrap team for the excellent CSS framework
- FPDF library for PDF generation capabilities
