<?php
// Include configuration
require_once 'includes/config.php';
require_once 'includes/rate_limiter.php';

// Initialize response
$response = [
    'success' => false,
    'message' => 'Invalid request'
];

// Check rate limiting
$rate_limiter = new RateLimiter(5, 3600); // 5 security verification attempts per hour (stricter)
if (!$rate_limiter->isAllowed($_SERVER['REMOTE_ADDR'], 'security_verify')) {
    $response['message'] = 'Too many verification attempts. Please try again later.';
    $_SESSION['flash_message'] = $response['message'];
    $_SESSION['flash_type'] = 'danger';
    header("Location: verify_gatepass.php");
    exit();
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $gatepass_id = isset($_POST['gatepass_id']) ? trim($_POST['gatepass_id']) : '';
    $security_code = isset($_POST['security_code']) ? trim($_POST['security_code']) : '';
    $verification_notes = isset($_POST['verification_notes']) ? trim($_POST['verification_notes']) : '';
    
    // Validate inputs
    if (empty($gatepass_id) || empty($security_code)) {
        $response['message'] = 'Gatepass ID and security code are required';
    } else {
        // Connect to database
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            $response['message'] = 'Database connection failed';
        } else {
            // First, validate the security code (this should be a more secure implementation)
            // For demo purposes, we're using a simple hardcoded check
            // In a real system, you'd check against security user credentials
            $valid_security_code = 'security123'; // This should be stored securely and not hardcoded
            
            if ($security_code !== $valid_security_code) {
                $response['message'] = 'Invalid security code';
            } else {                // Check if the gatepass exists and is valid
                $stmt = $conn->prepare("SELECT g.* FROM gatepasses g WHERE g.gatepass_number = ? 
                                       AND (g.status = 'approved_by_admin' OR g.status = 'approved_by_security' OR g.status = 'self_approved')");
                $stmt->bind_param("s", $gatepass_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    $response['message'] = 'Gatepass not found or not approved';
                } else {
                    $gatepass = $result->fetch_assoc();
                      // Check if already verified
                    if (!empty($gatepass['verified_at'])) {
                        $response['message'] = 'This gatepass has already been verified on ' . 
                                             date('d-m-Y H:i:s', strtotime($gatepass['verified_at']));
                    } else {
                        // Check if expired - calculate validity date as requested_date + 7 days
                        $valid_until = date('Y-m-d', strtotime($gatepass['requested_date'] . ' + 7 days'));
                        if (strtotime($valid_until) < strtotime(date('Y-m-d'))) {
                            $response['message'] = 'This gatepass has expired';
                        } else {
                            // All checks passed, mark as verified
                        // Update the gatepass as verified
                        $verified_by = "Security Portal"; // In a real system, you'd use the security personnel's name
                        $verified_at = date('Y-m-d H:i:s');
                          // Note: Check if these columns exist in the database schema
                        // Add them if they don't exist with an ALTER TABLE statement                        // Using security_approved fields for verification
                        $update_stmt = $conn->prepare("UPDATE gatepasses SET security_approved_by = 0, security_approved_at = ?, 
                                                      decline_reason = ? WHERE gatepass_number = ?");
                        // Only 3 parameters now
                        $update_stmt->bind_param("sss", $verified_at, $verification_notes, $gatepass_id);
                        // Already updated in the query above
                        
                        if ($update_stmt->execute()) {                            // Log the verification
                            $ip_address = $_SERVER['REMOTE_ADDR'];
                            $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
                            $log_stmt = $conn->prepare("INSERT INTO logs (action, details, ip_address, user_agent) 
                                                     VALUES ('Public Security Verification', ?, ?, ?)");
                            $details = "Gatepass ID: " . $gatepass_id . " | Notes: " . $verification_notes;
                            $log_stmt->bind_param("sss", $details, $ip_address, $user_agent);
                            $log_stmt->execute();
                            $log_stmt->close();
                            
                            $response['success'] = true;
                            $response['message'] = 'Gatepass has been successfully verified';
                            $response['verified_at'] = $verified_at;
                            $response['verified_by'] = $verified_by;
                        } else {
                            $response['message'] = 'Failed to update gatepass verification status';
                        }
                        
                        $update_stmt->close();
                    }
                }
                
                $stmt->close();
            }
            
            $conn->close();
        }
    }
}

// Set redirect URL with query parameters
$redirect_url = 'verify_gatepass.php?id=' . urlencode($gatepass_id);
if ($response['success']) {
    $redirect_url .= '&verified=true&ts=' . time();
} else {
    $redirect_url .= '&error=' . urlencode($response['message']);
}

// Store in session flash message
$_SESSION['flash_message'] = $response['message'];
$_SESSION['flash_type'] = $response['success'] ? 'success' : 'danger';

// Redirect back to verification page
header("Location: " . $redirect_url);
exit();
?>
