<?php
// Include configuration
require_once 'includes/config.php';
require_once 'includes/rate_limiter.php';

// Initialize variables
$error = '';
$gatepass = null;
$is_verified = false;
$verification_result = null;

// Check rate limiting
$rate_limiter = new RateLimiter(20, 3600); // 20 verifications per hour
if (!$rate_limiter->isAllowed($_SERVER['REMOTE_ADDR'], 'verify_gatepass')) {
    $error = "Too many verification attempts. Please try again later.";
}

// Check for flash messages from security verification
if (isset($_SESSION['flash_message']) && isset($_SESSION['flash_type'])) {
    $flash_message = $_SESSION['flash_message'];
    $flash_type = $_SESSION['flash_type'];
    // Clear the message after reading
    unset($_SESSION['flash_message']);
    unset($_SESSION['flash_type']);
}

// Check if gatepass_id is provided in URL or form
$gatepass_id = isset($_GET['id']) ? trim($_GET['id']) : (isset($_POST['gatepass_id']) ? trim($_POST['gatepass_id']) : '');

if (!empty($gatepass_id)) {
    // Connect to database
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        $error = "Database connection failed. Please try again later.";
    } else {        // Secure query to get gatepass details
        $stmt = $conn->prepare("SELECT g.*, u.name as requester_name
                               FROM gatepasses g 
                               JOIN users u ON g.created_by = u.id 
                               WHERE g.gatepass_number = ?");
        $stmt->bind_param("s", $gatepass_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $gatepass = $result->fetch_assoc();
            $is_verified = true;
              // Log this verification
            $ip_address = $_SERVER['REMOTE_ADDR'];
            $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
            $log_stmt = $conn->prepare("INSERT INTO logs (action, details, ip_address, user_agent) 
                                       VALUES ('Public Gatepass Verification', ?, ?, ?)");
            $details = "Gatepass ID: " . $gatepass_id;
            $log_stmt->bind_param("sss", $details, $ip_address, $user_agent);
            $log_stmt->execute();
            $log_stmt->close();
              // Determine the verification result
            $current_date = date('Y-m-d');
            // Calculate validity date as requested_date + 7 days (default validity period)
            $valid_until = date('Y-m-d', strtotime($gatepass['requested_date'] . ' + 7 days'));
            $gatepass['valid_until'] = $valid_until; // Set for use elsewhere in the page
              
            if ($gatepass['status'] != 'approved_by_admin' && $gatepass['status'] != 'approved_by_security' && $gatepass['status'] != 'self_approved') {
                $verification_result = [
                    'status' => 'not-approved',
                    'message' => 'This gatepass has not been approved yet.',
                    'class' => 'danger'
                ];
            } 
            elseif (strtotime($valid_until) < strtotime($current_date)) {
                $verification_result = [
                    'status' => 'expired',
                    'message' => 'This gatepass has expired on ' . date('d-m-Y', strtotime($valid_until)) . '.',
                    'class' => 'danger'
                ];
            }            elseif (!empty($gatepass['security_approved_at'])) {
                $verification_result = [
                    'status' => 'already-verified',
                    'message' => 'This gatepass has already been used on ' . date('d-m-Y H:i:s', strtotime($gatepass['security_approved_at'])) . '.',
                    'class' => 'warning'
                ];
            }
            else {
                $verification_result = [
                    'status' => 'valid',
                    'message' => 'This gatepass is valid and can be used until ' . date('d-m-Y', strtotime($gatepass['valid_until'])) . '.',
                    'class' => 'success'
                ];
            }
              // Get the items
            $items_stmt = $conn->prepare("SELECT * FROM gatepass_items WHERE gatepass_id = ?");
            $items_stmt->bind_param("i", $gatepass['id']);  // Using the gatepass id from the retrieved record
            $items_stmt->execute();
            $items_result = $items_stmt->get_result();
            $gatepass['items'] = [];
            
            while ($item = $items_result->fetch_assoc()) {
                $gatepass['items'][] = $item;
            }
            
            $items_stmt->close();
        } else {
            $error = "Gatepass not found. Please check the gatepass number and try again.";
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Gatepass - <?php echo APP_NAME; ?></title>
    
    <!-- Favicon -->
    <?php 
        $favicon_path = 'assets/img/';
    ?>
    <!-- Standard Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?php echo $favicon_path; ?>favicon.svg">
    <link rel="icon" type="image/png" href="<?php echo $favicon_path; ?>favicon.png" sizes="32x32">
    <link rel="icon" type="image/x-icon" href="<?php echo $favicon_path; ?>favicon.ico">
    
    <!-- Apple Touch Icon -->
    <link rel="apple-touch-icon" href="<?php echo $favicon_path; ?>favicon.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $favicon_path; ?>apple-touch-icon.png">
    
    <!-- Android Chrome -->
    <link rel="manifest" href="<?php echo $favicon_path; ?>site.webmanifest">
    <meta name="theme-color" content="#2c3e50">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        .verify-container {
            max-width: 700px;
            margin: 5% auto;
            padding: 30px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container i {
            font-size: 48px;
            color: #2c3e50;
        }
        .form-title {
            text-align: center;
            margin-bottom: 25px;
            color: #2c3e50;
        }
        .custom-btn {
            background-color: #2c3e50;
            border-color: #2c3e50;
            width: 100%;
        }
        .custom-btn:hover {
            background-color: #1a252f;
            border-color: #1a252f;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .footer {
            text-align: center;
            font-size: 0.85em;
            color: #6c757d;
            margin-top: 20px;
        }
        .footer a {
            color: #2c3e50;
        }
        .verification-status {
            text-align: center;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }
        .gatepass-details {
            margin-top: 30px;
        }
        .section-title {
            border-bottom: 2px solid #eee;
            padding-bottom: 8px;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        .detail-row {
            margin-bottom: 10px;
        }
        .badge-status {
            font-size: 1em;
            padding: 7px 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="verify-container">
            <div class="logo-container">
                <i class="fas fa-id-card-alt"></i>
                <h2 class="mt-2"><?php echo APP_NAME; ?></h2>
            </div>
            
            <h3 class="form-title">Verify Gatepass</h3>
              <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo $error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($flash_message)): ?>
                <div class="alert alert-<?php echo $flash_type; ?> alert-dismissible fade show" role="alert">
                    <?php echo $flash_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['error'])): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo htmlspecialchars($_GET['error']); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            
            <?php if (!$is_verified): ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
                <div class="mb-4">
                    <label for="gatepass_id" class="form-label">Gatepass Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-passport"></i></span>
                        <input type="text" class="form-control" id="gatepass_id" name="gatepass_id" placeholder="Enter gatepass number" required>
                    </div>
                    <small class="form-text text-muted">Enter the gatepass number to verify its authenticity.</small>
                </div>
                
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary custom-btn">
                        <i class="fas fa-search me-2"></i>Verify Gatepass
                    </button>
                </div>
            </form>
            <?php else: ?>
                <?php if ($verification_result): ?>
                <div class="verification-status alert alert-<?php echo $verification_result['class']; ?>">
                    <h4 class="alert-heading">
                        <?php if ($verification_result['status'] == 'valid'): ?>
                            <i class="fas fa-check-circle me-2"></i>Valid Gatepass
                        <?php elseif ($verification_result['status'] == 'already-verified'): ?>
                            <i class="fas fa-exclamation-triangle me-2"></i>Already Used
                        <?php elseif ($verification_result['status'] == 'expired'): ?>
                            <i class="fas fa-times-circle me-2"></i>Expired Gatepass
                        <?php else: ?>
                            <i class="fas fa-ban me-2"></i>Not Approved
                        <?php endif; ?>
                    </h4>
                    <p><?php echo $verification_result['message']; ?></p>
                </div>
                
                <div class="gatepass-details">
                    <h4 class="section-title">Gatepass Information</h4>
                      <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Gatepass Number:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($gatepass['gatepass_number']); ?></div>
                    </div>
                    
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Requester:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($gatepass['requester_name']); ?></div>
                    </div>
                      <!-- Department information removed as it's not available in the database -->
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">From Location:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($gatepass['from_location']); ?></div>
                    </div>
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">To Location:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($gatepass['to_location']); ?></div>
                    </div>
                    
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Purpose:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($gatepass['purpose']); ?></div>
                    </div>
                    
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Issue Date:</div>
                        <div class="col-md-8"><?php echo date('d-m-Y', strtotime($gatepass['created_at'])); ?></div>
                    </div>
                    
                    <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Valid Until:</div>
                        <div class="col-md-8"><?php echo date('d-m-Y', strtotime($gatepass['valid_until'])); ?></div>
                    </div>
                      <div class="row detail-row">
                        <div class="col-md-4 fw-bold">Status:</div>
                        <div class="col-md-8">
                            <span class="badge bg-<?php echo (in_array($gatepass['status'], ['approved_by_admin', 'approved_by_security', 'self_approved'])) ? 'success' : 'warning'; ?> badge-status">
                                <?php 
                                    $status = str_replace('_', ' ', $gatepass['status']);
                                    echo ucwords($status); 
                                ?>
                            </span>
                        </div>
                    </div>
                    
                    <h4 class="section-title mt-4">Items</h4>
                    <table class="table table-bordered table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Returnable</th>
                                <th>Return Date</th>
                            </tr>
                        </thead>
                        <tbody>                            <?php foreach ($gatepass['items'] as $i => $item): ?>
                            <tr>
                                <td><?php echo $i+1; ?></td>
                                <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']) . ' ' . htmlspecialchars($item['unit']); ?></td>
                                <td>
                                    <?php if ($item['is_returnable']): ?>
                                    <span class="badge bg-info">Yes</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo ($item['is_returnable']) 
                                              ? date('d-m-Y', strtotime($item['return_date'])) 
                                              : 'N/A'; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                      <?php if ($verification_result['status'] == 'valid'): ?>
                    <div class="alert alert-info mt-4">
                        <i class="fas fa-info-circle me-2"></i> This gatepass is authentic and valid. Please proceed with security verification at the gate.
                    </div>
                    
                    <!-- Security verification button/form -->
                    <div class="card mt-4 mb-4 border-primary">
                        <div class="card-header bg-primary text-white">
                            <i class="fas fa-shield-alt me-2"></i>Security Verification
                        </div>
                        <div class="card-body">
                            <p>If you are security personnel, you can mark this gatepass as verified/used:</p>
                            <form id="securityVerifyForm" method="post" action="security_verify.php">
                                <input type="hidden" name="gatepass_id" value="<?php echo htmlspecialchars($gatepass_id); ?>">
                                <div class="mb-3">
                                    <label for="securityCode" class="form-label">Security Code</label>
                                    <input type="password" class="form-control" id="securityCode" name="security_code" 
                                           placeholder="Enter security verification code" required>
                                    <small class="form-text text-muted">This code is provided to security personnel only.</small>
                                </div>
                                <div class="mb-3">
                                    <label for="verificationNotes" class="form-label">Verification Notes (Optional)</label>
                                    <textarea class="form-control" id="verificationNotes" name="verification_notes" 
                                              rows="2" placeholder="Any notes about this verification"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-check-circle me-2"></i>Mark as Verified/Used
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="text-center mt-4">
                    <a href="public_download.php?gatepass_id=<?php echo urlencode($gatepass_id); ?>" class="btn btn-secondary">
                        <i class="fas fa-download me-2"></i>Download PDF
                    </a>
                    <a href="verify_gatepass.php" class="btn btn-outline-secondary ms-2">
                        <i class="fas fa-search me-2"></i>Verify Another Gatepass
                    </a>
                </div>
                <?php endif; ?>
            <?php endif; ?>
              <div class="back-link">
                <a href="index.php">Back to Login</a> | 
                <a href="public_download.php">Download Gatepass</a> |
                <a href="public_services.php">Public Services Portal</a>
            </div>
            
            <div class="footer">
                <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?> - Developed by <a href="copyright.php">Piyush Maji</a></p>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
